from sqlalchemy import create_engine

def test_connection(connection_string):
    try:
        engine = create_engine(connection_string)
        with engine.connect() as conn:
            print(f"Connection successful for {connection_string}")
    except Exception as e:
        print(f"Connection failed for {connection_string}: {e}")

# Replace with your actual connection strings
flipkart_conn = "mysql+pymysql://root:root@localhost:3306/flipkart_db"
amazon_conn = "mysql+pymysql://root:root@localhost:3306/amazon_db"
central_conn = "mysql+pymysql://root:root@localhost:3306/central_db"

test_connection(flipkart_conn)
test_connection(amazon_conn)
test_connection(central_conn)
