import json
from sqlalchemy import create_engine, MetaData, Table, select, union_all, text, literal
from sqlalchemy.exc import SQLAlchemyError
from rapidfuzz import fuzz
import re
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

GLOBAL_SCHEMA = {
    'product_id': {'type': 'string'},
    'name': {'type': 'string'},
    'price': {'type': 'float'},
    'rating': {'type': 'float'},
    'category': {'type': 'string'},
    'source': {'type': 'string'}
}

SYNONYMS = {
    'product_id': ['asin', 'sku', 'item_id', 'id', 'product_code', 'product_number', 'product_identifier', 'product_reference', 'product_sku', 'product_asin', 'product_ean', 'product_upc', 'product_gtin', 'product_isbn', 'product_code', 'product_number', 'product_identifier', 'product_reference', 'product_sku', 'product_asin', 'product_ean', 'product_upc', 'product_gtin', 'product_isbn'],
    'price': ['cost', 'amount', 'value', 'discounted_price', 'selling_price', 'actual_price'],
    'name': ['title', 'name', 'product_name'],
    'rating': ['review_score', 'avg_rating', 'product_rating', 'customer_rating'],
    'category': ['product_type', 'product_category', 'main_category', 'sub_category', 'category_name', 'product_group', 'product_line', 'category_1', 'category_2', 'category_3']
}

def load_schema_mappings(config_file='schema_mappings.json'):
    with open(config_file, 'r') as f:
        return json.load(f)

def clean_column_name(name):
    return re.sub(r'\W+', '', name).lower()

def find_best_match(global_attr, source_columns):
    best_match = None
    highest_score = 0
    possible_matches = [global_attr] + SYNONYMS.get(global_attr, [])
    for col in source_columns:
        for candidate in possible_matches:
            score = fuzz.token_set_ratio(candidate, col)
            logging.debug(f"Matching Global Attribute '{global_attr}' with Source Column '{col}': Score {score}")
            if score > highest_score:
                highest_score = score
                best_match = col
    if best_match and highest_score >= 70:
        logging.info(f"Best match for '{global_attr}' is '{best_match}' with score {highest_score}")
        return best_match
    else:
        logging.warning(f"No adequate match found for '{global_attr}'. Highest score: {highest_score}")
        return None

def create_select_statement(source_config):
    try:
        logging.info(f"Processing source: {source_config['name']}")
        engine = create_engine(source_config['connection_string'])
        metadata = MetaData()

        metadata.reflect(bind=engine)

        main_table_name = source_config.get('table')
        if not main_table_name:
            main_table = max(metadata.tables.values(), key=lambda t: len(t.columns))
            logging.info(f"No table specified for source '{source_config['name']}'. Using table '{main_table.name}'.")
        else:
            if main_table_name not in metadata.tables:
                logging.error(f"Table '{main_table_name}' not found in source '{source_config['name']}'.")
                return None
            database_name = engine.url.database
            main_table = Table(main_table_name, metadata, schema=database_name, autoload_with=engine)

        from_clause = main_table

        select_columns = []
        mappings = source_config.get('mappings', {})
        source_columns = {clean_column_name(col.name): col for col in main_table.columns}

        column_mappings = {}
        for global_attr in GLOBAL_SCHEMA.keys():
            if global_attr == 'source':
                continue  # 'source' is added manually

            if global_attr in mappings:
                source_attr = mappings[global_attr]
                if isinstance(source_attr, dict):
                    related_table_name = source_attr['table']
                    if related_table_name not in metadata.tables:
                        logging.error(f"Related table '{related_table_name}' not found in source '{source_config['name']}'.")
                        return None
                    related_table = Table(source_attr['table'], metadata, schema=database_name, autoload_with=engine)
                    join_condition = main_table.c[source_attr['join_on']] == related_table.c[source_attr['key']]
                    from_clause = from_clause.join(related_table, join_condition)
                    column_mappings[global_attr] = related_table.c[source_attr['value']]
                    logging.info(f"Mapped '{global_attr}' to '{source_attr['value']}' via join with '{related_table_name}'.")
                else:
                    if source_attr not in main_table.columns:
                        logging.error(f"Column '{source_attr}' not found in table '{main_table.name}' for source '{source_config['name']}'.")
                        return None
                    column_mappings[global_attr] = main_table.c[source_attr]
                    logging.info(f"Mapped '{global_attr}' to '{source_attr}' in table '{main_table.name}'.")
            else:
                match = find_best_match(global_attr, source_columns.keys())
                if match:
                    column_mappings[global_attr] = source_columns[match]
                else:
                    related_column = find_in_related_tables(global_attr, engine, metadata, main_table)
                    if related_column is not None:
                        from_clause = from_clause.join(related_column['table'], related_column['condition'])
                        column_mappings[global_attr] = related_column['column']
                    else:
                        logging.warning(f"No match found for attribute '{global_attr}' in source '{source_config['name']}'.")
                        return None  # Skip this source if essential attributes are missing

        for global_attr, source_col in column_mappings.items():
            select_columns.append(source_col.label(global_attr))
            logging.debug(f"Selected column '{source_col.key}' as '{global_attr}'.")

        select_columns.append(literal(source_config['name']).label('source'))
        logging.debug("Added 'source' identifier.")

        select_stmt = select(*select_columns).select_from(from_clause)
        logging.info(f"Select statement for source '{source_config['name']}' created successfully.")

        return select_stmt

    except SQLAlchemyError as e:
        logging.error(f"Error processing source {source_config['name']}: {e}")
        return None

def find_in_related_tables(global_attr, engine, metadata, main_table):
    for fk in main_table.foreign_keys:
        related_table = fk.column.table
        try:
            related_table = Table(related_table.name, metadata, schema=related_table.schema, autoload_with=engine)
            related_columns = {clean_column_name(col.name): col for col in related_table.columns}
            match = find_best_match(global_attr, related_columns.keys())
            if match:
                join_condition = main_table.c[fk.parent.name] == related_table.c[fk.column.name]
                logging.info(f"Found '{match}' in related table '{related_table.name}' for attribute '{global_attr}'.")
                return {
                    'table': related_table,
                    'column': related_columns[match],
                    'condition': join_condition
                }
        except SQLAlchemyError as e:
            logging.error(f"Error reflecting related table '{related_table.name}': {e}")
            continue
    return None

def create_global_products_view(schema_mappings):
    select_statements = []
    for source in schema_mappings['data_sources']:
        select_stmt = create_select_statement(source)
        if select_stmt is not None:
            select_statements.append(select_stmt)
        else:
            logging.warning(f"Source '{source['name']}' was skipped due to mapping issues.")

    if not select_statements:
        logging.error("No valid data sources found. Exiting script.")
        return

    combined_select = union_all(*select_statements)
    logging.info("Combined select statements using UNION ALL.")

    central_conn_str = schema_mappings['central_database']['connection_string']
    central_engine = create_engine(central_conn_str)
    central_metadata = MetaData()
    view_name = 'GlobalProducts'
    try:
        compiled_query = combined_select.compile(central_engine, compile_kwargs={'literal_binds': True})
        view_sql = f"CREATE OR REPLACE VIEW {view_name} AS {str(compiled_query)}"
        with central_engine.connect() as conn:
            conn.execute(text(f"DROP VIEW IF EXISTS {view_name}"))
            conn.execute(text(view_sql))
        logging.info(f"Global view '{view_name}' created successfully.")
    except SQLAlchemyError as e:
        logging.error(f"Error creating global view: {e}")

if __name__ == "__main__":
    schema_mappings = load_schema_mappings()
    create_global_products_view(schema_mappings)
